# 第 10 周开发任务：仿写法——从 Ethernet 样例到三个骨架

**周次**：校历第 10 周（11 月 4 日）　**对应功能项**：F2、F3（协议解析器）
**截止时间**：下周二(11月10日) 12:00 前，与周报同时提交　**预计用时**：约 2.5 小时

## 一、任务目标

1. 精读 ethernet【样例】模块，掌握一个协议解析器的结构与编写规范；
2. 按同一规范补全 ipv4、arp、icmp 三个【骨架】模块的 TODO 函数体；
3. 补全后引擎在 sample.pcap 上仍可跑出 40 / 0，逐包字段值合理。

**周末状态**：三个骨架无 TODO 残留；`engine.exe pcap\sample.pcap` 输出 40 / 0；能讲清"新增一个解析模块要动哪几个文件"。

## 二、前置检查

- [ ] 引擎可编译可运行，`engine.exe pcap\sample.pcap` 输出与预期一致（40 / 0）（第 9 周）
- [ ] 《项目结构说明》已提交（第 9 周任务二）
- [ ] `git log --oneline` 可见上周 ≥3 条 commit

## 三、任务清单

边界：本周只做字段解析。ARP/ICMP 不进流、不进统计（第 14 周 flow_table 起）；TCP/UDP 只留分发注释（第 12 周）。

### ① 补全 ipv4 骨架（约 90 分钟）

建议动手前先把每个 TODO 步骤对应到 `ethernet.cpp` 的具体段落，想清楚再写；例会上可能指着某个 TODO 问对应样例的哪段写法。

实现 `parse_ipv4`，字段级步骤按 `ipv4.cpp` 顶部 TODO 注释逐条做：

- ByteReader + try-catch 包住全部读取，越界时 `pkt.parse_errors++`、累加全局异常计数后返回 false；
- 头长 = IHL × 4，须 ≥ 20；总长度须 ≤ 实际捕获长度；
- `ip_frag`：MF == 1 或片偏移 > 0 即置 true；
- `ipv4_src` / `ipv4_dst`：4 字节转点分十进制字符串，缓冲区 16 字节；
- 置 `pkt.has_ipv4 = true`，按 `ipv4_proto` 留分发注释：6→TCP、17→UDP、1→ICMP，本周不实现传输层。

自验：重新编译运行，`engine.exe pcap\sample.pcap --jsonl out.jsonl`，抽查几个 IPv4 包的字段值是否合理（见第四节）。

### ② 补全 arp、icmp 骨架（约 60 分钟）

按 `arp.cpp` / `icmp.cpp` 顶部 TODO 步骤实现：

- ARP：读操作码 op，置 `pkt.has_arp = true`、`pkt.arp_op = op`；htype/ptype/hlen/plen 与发送方、目标方 MAC/IP 可继续读取，按需扩展；
- ICMP：读 type、code，置 `pkt.has_icmp = true`、`pkt.has_icmp_fields = true`、`pkt.icmp_type`、`pkt.icmp_code`；
- 字段名一律以 `src/proto/parser.h` 的 Packet 结构体为准，两模块同样走 ByteReader + try-catch 套路。

自验：`--jsonl` 输出中 ICMP 包 type 为 0 或 8；跑一次 `engine.exe pcap\malformed.pcap`，全程不崩溃、正常退出。sample.pcap 的 40 个包全是 IPv4，无 ARP 流量，ARP 分支保证编译通过、被 ethernet 正确分发即可。

## 四、自验方法：--jsonl 字段抽查

```text
engine.exe pcap\sample.pcap --jsonl out.jsonl
```

逐包解析字段写入 out.jsonl，用编辑器逐行查看。合理性判据：

| 字段 | 合理表现 |
| --- | --- |
| ipv4_src / ipv4_dst | 形如 192.168.x.x 的点分十进制，不是乱码或 0.x 开头的错位值 |
| ipv4_ttl | 常见值 64、128、255 |
| icmp_type | 0（reply）或 8（request） |
| parse_errors | sample.pcap 上保持 0 |

sample.pcap 的 40 个包全是 IPv4，无 ARP 流量；ARP 分支保证编译通过、被 ethernet 正确分发即可。

出现怪值先查字节序，字段错位先查 IHL×4。

## 五、输出物与提交

| 输出物 | 位置 |
| --- | --- |
| 补全后的三个骨架 | `src/proto/ipv4.{h,cpp}`、`src/proto/arp.{h,cpp}`、`src/proto/icmp.{h,cpp}` |
| 周报 | `docs/weekly/week10_report.md`（周二 12:00 前，单独一次 `docs:` 提交） |

本周有效 commit 不少于 3 条，含周报一次。commit 建议：

- `feat: 补全 ipv4 骨架解析`
- `feat: 补全 arp/icmp 骨架解析`
- `docs: 第10周周报`

## 六、验收标准

1. 工程编译通过，`engine.exe pcap\sample.pcap` 输出 40 / 0，解析异常数不增加；
2. 三个骨架无 TODO 残留，截断输入不崩溃且计入 `parse_errors`；
3. ≥3 条有效 commit，含周报一次。

## 附：耗时自评栏（学生填写，并入周报第四节）

| 任务项 | 预估 | 实际 | 卡点说明 |
| --- | --- | --- | --- |
| ① 补全 ipv4 骨架 | 90 min | | |
| ② 补全 arp、icmp 骨架 | 60 min | | |
