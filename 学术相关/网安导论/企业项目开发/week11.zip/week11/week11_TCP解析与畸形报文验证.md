# 第 11 周任务卡：TCP 解析与畸形报文验证

## 速览

- **目标**：畸形样例逐类核对留档；补全 tcp 骨架，解析六大标志位，与 Wireshark 逐包一致；实现 IPv4 头校验和检查；分析教师下发的第 7 类畸形样例。
- **截止**：周二(11月17日) 12:00 前提交（与周报同时）。
- **本周要编写的代码**：
  - `src/proto/tcp.cpp` 的 `parse_tcp` 函数体——端口、data_offset、六大标志位解析，头长越界计入 parse_errors
  - `src/proto/ipv4.cpp` 两处——protocol 分发接上 `parse_tcp`；加校验和检查分支（任务④）
  - `tests/test_tcp.cpp`（新增）——骨架见附二，补全三条用例的断言
- **本周任务（同正文编号）**：
  - ① 样例解读与跑测→ `docs/notes/week11_malformed.md`
  - ② 补全 tcp 骨架 + 单测
  - ③ 全量回归
  - ④ IPv4 头校验和检查
  - ⑤ 分析第 7 类畸形样例
- **周末应达到的状态**：
  1. `engine.exe pcap/malformed.pcap` 全程不崩溃，6 类样例逐类有"预期—实际"处理记录，TCP 越界样例 parse_errors > 0；
  2. tcp 骨架无 TODO，`test_tcp` 全绿，端口与标志位与 Wireshark 逐包一致；
  3. 校验和错误样例被检出且计数 ≥1；
  4. `sample.pcap` 回归 40 / 0；
  5. 第 7 类样例（`malformed_extra.pcap`）parse_errors > 0，分析已写入记录文档。
- **验收方式**：①现场运行 malformed.pcap，不崩溃、计数可查；②六类样例及第 7 类教师样例逐类能说明处理方式；③指出 6 个标志位的比特位置，`test_tcp` 全绿；④回归零误差、≥3 条有效 commit。

---

## 一、本周目标

1. 对 malformed.pcap 六类畸形样例逐类核对，将"截断不崩溃、越界计数"落实为留档证据；
2. 补全 tcp 骨架，解析端口、data_offset 与六大标志位——传输层协议先完成复杂度较高的 TCP；
3. 实现 IPv4 头校验和检查（仅记录计数口径）；
4. 分析教师下发的第 7 类畸形样例（TCP data_offset 声明小于最小头长），完成跑测并留档。

## 二、前置检查（上周回顾）

- [ ] ipv4、arp、icmp 三个骨架已补全、无 TODO 残留（第 10 周任务产出）
- [ ] `engine.exe pcap/sample.pcap` 输出 40 / 0
- [ ] `engine.exe pcap/malformed.pcap` 运行不崩溃（第 10 周自验项）
- [ ] 上周有效 commit ≥3 条，`git log --oneline` 可见

> 未过项请先找助教补齐。任务②的实现依赖第 10 周三个骨架的既有写法。

## 三、输入材料

| 文件或章节 | 内容 | 必读/参考 |
|---|---|---|
| `pcap/malformed.pcap` | 畸形包测试集（6 畸形 + 1 正常对照） | 必读 |
| `src/proto/tcp.{h,cpp}` | TCP 解析骨架（函数体 TODO） | 必读 |
| `src/proto/ipv4.cpp` | 第 10 周已完成的 ipv4 解析——tcp 写法参照它；任务④在此加校验和分支 | 必读 |
| `src/proto/parser.h` | `Packet` 结构体：tcp 需填 has_tcp / src_port / dst_port / tcp_flags | 必读 |
| `src/util/byte_reader.h` | u16be / u8 / skip 接口 | 复用 |
| `tests/test_ethernet.cpp` | 单元测试模板 | 必读 |
| 计划书 5.5 节 | 六类畸形样例规格与"校验和仅记录计数"口径 | 必读 |

## 四、任务清单

### 任务明细

**① 样例解读与跑测**

核对 malformed.pcap 六类样例在第 10 周代码下的处理结果，建立跑测基准。本任务不涉及代码编写，无需安装 Python。7 条样例的畸形点与预期行为课件已逐条给出，不需要抄表。

步骤：

1. 理解样例：7 条样例各自的畸形点、Wireshark 表现、第 10 周代码能否处理，课件已逐条给出——TCP 头越界与校验和错误两类第 10 周代码检不出，正是本周任务②④要解决的；
2. 在仓库根目录执行：

   ```text
   engine.exe pcap\malformed.pcap
   engine.exe pcap\malformed.pcap --jsonl out.jsonl
   ```

   第一条命令：记录终端汇总行"处理包数 / 解析异常数"。第二条命令：生成逐包解析文件 out.jsonl（7 行，每行一个包），用 VS Code 逐行查看哪 3 条计了错、哪 4 条没有。
3. 文档不用自己设计——把下面这份模板原样复制为 `docs/notes/week11_malformed.md`，跑完把空格（`__`）照实填上，括号里的提示文字可保留：

   ```markdown
   # 第 11 周跑测与回归记录

   ## 一、解析异常数演进表

   | 时点 | 命令 | 终端汇总（处理包数/解析异常数） | 哪几条样例被检出 |
   |---|---|---|---|
   | 任务①（第 10 周代码） | engine.exe pcap\malformed.pcap | __ / __ | |
   | 任务②完成后（写完 parse_tcp） | engine.exe pcap\malformed.pcap | __ / __ | |
   | 任务④完成后（加完校验和检查） | engine.exe pcap\malformed.pcap | __ / __ | |

   ## 二、第 7 类样例分析（任务⑤填"实际"一行，其余已给）

   - 畸形点：合法 SYN 包仅改 TCP 第 12 字节 0x50→0x40，声明头长 16 字节，小于最小 20
   - 预期：不崩溃，parse_errors +1
   - 实际：__
   - 对照：与第 4 样例是一对——第 4 样例声明 60 比实际 20 大（考上界），本条声明 16 比最小 20 小（考下界）

   ## 三、回归记录（任务③填数字）

   - ctest：__ / __ 通过
   - engine.exe pcap\sample.pcap：处理包数 __，解析异常数 __（应与第 10 周的 40 / 0 一致）
   - flags 抽查：--jsonl 中 TCP 包 flags 仅出现 0x02/0x12/0x10/0x18/0x11 五种
   ```

验收：`docs/notes/week11_malformed.md` 已按模板建好（三节齐全），演进表第一行（基准数字）已填；能说明：3 类计入错误（截断 IP 头、声明长度越界、零长度包）、1 类不计（未知 ethertype）、2 类暂不检出（TCP 头越界、校验和错误）。

依赖：无。

**② 补全 tcp 骨架 + 单测**

实现 `parse_tcp` 的端口与六大标志位解析，并配套单元测试。

步骤：

1. 先阅读 `tcp.h` 中各 TODO，逐一对应 `ethernet.cpp`／`ipv4.cpp` 中的实现段落，再开始编码；例会抽查可能要求指出某个 TODO 对应的样例段落；
2. 使用 `util::ByteReader` 读取 src_port、dst_port、data_offset、标志位字节并填入 `Packet`；按位判断一律使用按位与，如 `(flags & 0x02) != 0`，不使用逻辑与 `&&`；
3. 边界检查：头长超出捕获长度或小于 20 字节时，累加 `parse_errors` 并返回 false；
4. 在 `src/proto/ipv4.cpp` 的 protocol 分发中让 6（TCP）调用 `parse_tcp`，参考写法 `case 6: parse_tcp(pkt, payload, payload_len); break;`；第 10 周的分发里没有 case 6 或它是空的，补上即可；不做这步，解析器不会被调用；
5. 新增 `tests/test_tcp.cpp`：骨架见本卡附二（输入数据包已备好，三条用例框架已搭好），补全每条用例的 REQUIRE 断言；在 CMakeLists 的 `add_executable(unit_tests …)` 清单中登记新文件并重新执行 cmake，否则 ctest 无法发现新用例；
6. 自验：重新编译运行 `engine.exe pcap\sample.pcap`，输出仍为 40 / 0；`--jsonl` 中 TCP 包端口与 flags 正确；重跑 malformed.pcap，TCP 头越界样例 `parse_errors` > 0，把演进表"任务②完成后"一行填上（解析异常数应较基准多 1）。

验收：tcp.cpp 无 TODO；`ctest -R tcp` 全部通过；随机抽取 5 个 TCP 包，标志位与 Wireshark Flags 列逐位一致；malformed.pcap 的 TCP 越界样例有字段级计数记录。

依赖：第 10 周骨架补全经验。

**③ 全量回归**

验证 tcp 骨架未破坏正常解析路径。

步骤（按顺序执行）：

```text
ctest          # 在 build 目录执行；注册表只存在于构建目录，在源码目录跑会报 "No tests were found"
engine.exe pcap\sample.pcap
engine.exe pcap\sample.pcap --jsonl out.jsonl
```

第一条要求全部测试通过；第二条输出须与第 10 周完全一致（处理包数 40、解析异常数 0）；第三条抽查 TCP 包：端口合理，flags 仅出现 0x02/0x12/0x10/0x18/0x11 五种取值。

验收：`week11_malformed.md` 第三节"回归记录"的数字已填，结论"零误差"。

依赖：任务②。

**④ IPv4 头校验和检查与错误计数**

按"仅记录计数"口径实现 IPv4 头校验和检查：检出错误时照常解析字段，记入日志与计数器。

步骤：

1. 校验和算法：头 20 字节按 16 位大端分段求和，结果取反后与收到的校验和字段比较，不一致即判错（算法细节见计划书 5.5）；
2. 在 `src/proto/ipv4.cpp` 中加校验和计算分支，位置在长度校验之后、字段填充之前；开关默认开启，关闭方式以注释写在代码中；
3. 判错时只记日志与计数，照常解析并返回 true。

验收：重跑 `engine.exe pcap\malformed.pcap`，把演进表"任务④完成后"一行填上——解析异常数应较任务①基准多 2（第 4 条由任务②检出、第 6 条由本任务检出，各 +1）；重跑 `engine.exe pcap\sample.pcap` 仍输出 40 / 0。

依赖：任务①③。

**⑤ 分析第 7 类畸形样例**

分析教师下发的 `pcap/malformed_extra.pcap`（第 7 类畸形样例），完成跑测并留档。

样例说明：该样例为合法 IPv4/TCP SYN 包，仅将 TCP 头第 12 字节由 `0x50` 改为 `0x40`——`data_offset` 由 5 变为 4，声明头长 16 字节，小于 TCP 固定头最小值 20 字节；IP 校验和已重新计算正确，全包唯一畸形点为该字节。与 malformed.pcap 第 4 样例（`data_offset=15`，声明 60 大于实际 20，考头长上界）对照，本条考头长下界，对应任务②中 `hdr_len < 20` 检查。

步骤：

1. 执行 `engine.exe pcap\malformed_extra.pcap`。教师参考实现实测结果：不崩溃，处理包数 1、解析异常数 1，日志 WARN `tcp 头长越界: 声明 16 字节, 实际 20`；
2. 在文档"第 7 类样例分析"一节把"实际"一行填上（其余文字模板已给）；

验收：文档含“第 7 类样例分析”一节且实际行为已填；能说明 16 字节头长错误的原因（协议规定固定头最小 20 字节）。

依赖：任务②。任务②未完成时执行本样例，引擎不会检出异常，属正常情况；可待任务②完成后再运行并补记。

## 五、输出物与提交要求

| 输出物 | 位置 |
|---|---|
| 跑测演进记录 + 第 7 类样例分析 + 回归记录 | `docs/notes/week11_malformed.md` |
| tcp 模块实现 | `src/proto/tcp.cpp` |
| 单元测试 | `tests/test_tcp.cpp` |
| 分发接入 + 校验和检查 | `src/proto/ipv4.cpp` |
| 周报 | `docs/weekly/week11_report.md`（周二 12:00 前，一次 `docs:` 提交，计入本周 ≥3 次有效提交） |

提交要求：本周有效 commit ≥3 条（含周报一次），格式 `type: 说明`。commit 建议：`docs: 畸形样例解读与跑测记录`、`feat: 补全 tcp 标志位解析`、`feat: 实现 ipv4 头校验和检查`、`docs: 第11周周报`。

## 附一：test_tcp.cpp 骨架（复制到 tests/ 下使用，补全 TODO 处的断言）

已备好：输入数据包 `kTcpSyn`（20 字节合法 SYN 头）、三条用例框架、标签。
待补全：每条用例的 `REQUIRE` 断言（对照 Packet 字段与计数器）。

```cpp
// ============================================================================
// test_tcp.cpp —— TCP 解析单元测试（仿 tests/test_ethernet.cpp）
// 骨架交付: 输入数据包已造好, 用例框架已搭好; 请补全每条 TODO 的断言。
// ============================================================================
#include "proto/tcp.h"
#include "util/logger.h"

#include <catch2/catch_test_macros.hpp>

#include <cstring>

namespace {
// 一个最小合法 TCP 头（20 字节，SYN 包）：
//   src_port 50000 | dst_port 80 | seq 1000 | ack 0
//   第 12 字节 0x50（data_offset=5 → 头长 20）| 第 13 字节 0x02（SYN）
const uint8_t kTcpSyn[] = {
    0xc3, 0x50,                    // src_port = 50000
    0x00, 0x50,                    // dst_port = 80
    0x00, 0x00, 0x03, 0xe8,        // seq = 1000
    0x00, 0x00, 0x00, 0x00,        // ack = 0
    0x50,                          // 第 12 字节：data_offset=5 → 头长 20 字节
    0x02,                          // 第 13 字节：SYN
    0x20, 0x00,                    // window
    0x44, 0x9b,                    // checksum（引擎读走不验）
    0x00, 0x00,                    // urgent
};
} // namespace

// 用例 1：正常 SYN 包——照 test_ethernet"正常帧"的断言套路
TEST_CASE("tcp 解析 SYN 包", "[tcp]") {
    util::reset_counters();
    pkt::Packet pkt;
    const bool ok = parse_tcp(pkt, kTcpSyn, sizeof(kTcpSyn));
    // TODO: 断言 ok、has_tcp、src_port/dst_port、tcp_flags、parse_errors
}

// 用例 2：ACK+PSH——只改第 13 字节，逐位断言 6 个标志（&& 笔误的照妖镜）
TEST_CASE("tcp ACK+PSH 标志位逐位检查", "[tcp]") {
    util::reset_counters();
    uint8_t buf[sizeof(kTcpSyn)];
    std::memcpy(buf, kTcpSyn, sizeof(kTcpSyn));
    buf[13] = 0x18;                // ACK+PSH
    pkt::Packet pkt;
    const bool ok = parse_tcp(pkt, buf, sizeof(buf));
    // TODO: 逐位断言 SYN=0、ACK=1、PSH=1 等
}

// 用例 3：截断包头——数组不动、长度传 10，照 test_ethernet"截断帧"的套路
TEST_CASE("tcp 截断包头不崩溃并计数", "[tcp][robust]") {
    util::reset_counters();
    pkt::Packet pkt;
    const bool ok = parse_tcp(pkt, kTcpSyn, 10);   // 只给 10 字节
    // TODO: 断言 ok==false、不终止、parse_errors 与全局计数各 +1
}
```
