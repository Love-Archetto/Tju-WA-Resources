# 第 12 周任务卡：UDP 解析与 TCP 连接状态识别

## 速览

- **目标**：补全 udp 骨架，传输层解析全部完成；按报文序列推断 TCP 连接状态，与 Wireshark 逐包一致；补全 TCP 其余字段；整包比对。
- **截止**：周二(11月24日) 12:00 前提交（与周报同时）。
- **本周要编写的代码**：
  - `src/proto/udp.cpp` 的 `parse_udp` 函数体——端口与 length 解析，越界计入 parse_errors
  - `src/proto/ipv4.cpp`——取消 `case 17` 一行注释，`parse_udp` 接入分发链
  - `src/proto/tcp.cpp`——seq/ack_num/window 填入 Packet；`infer_tcp_state` 函数体（签名与规则见 tcp.h 下发更新）
  - `tests/test_tcp.cpp`——3 条状态推断单测（骨架见附一）
- **本周下发文件（同步到本仓库）**：
  - `src/proto/tcp.h`——覆盖替换：新增 TcpConnState 枚举与 infer_tcp_state 签名，parse_tcp 原有声明不变；
  - `src/proto/parser.h`——覆盖替换：Packet 新增 seq / ack_num / window 字段，其余内容不变；
  - `pcap/flags.pcap`、`pcap/gen_flags.py`——新增：标志位样例集及其生成脚本，脚本仅备查，本周不执行；
  - 注意：自己的 `src/proto/tcp.cpp` 不要被覆盖——infer_tcp_state 函数体写在你第 11 周的 tcp.cpp 里。
- **本周任务（同正文编号）**：
  - ① 补全 udp 骨架
  - ② 连接状态推断 → 3 条会话对照表
  - ③ TCP 其余字段 seq/ack_num/window
  - ④ 整包比对：协议分布包数/字节
  - ⑤ flags.pcap 标志位核对
- **周末应达到的状态**：
  1. udp.cpp 无 TODO，`--jsonl` 中 UDP 包端口与 length 合理，sample.pcap 仍输出 40 / 0；
  2. 3 条会话"标志位—推断状态"对照表与 Wireshark 逐包一致，3 条状态单测全绿；
  3. seq/ack/window 与 Wireshark 抽包一致；协议分布包数比对零误差。
- **验收方式**：①udp 无 TODO、`--jsonl` 中 UDP 包端口与 length 合理；②3 条会话对照表与 Wireshark 逐包一致，状态单测全绿；③协议分布包数比对误差为零。

---

## 一、本周目标

1. 补全 udp 骨架——按字节偏移解析 UDP 头 8 字节，传输层解析全部完成；
2. 补全 tcp.h 下发的 `infer_tcp_state`，按报文序列推断 TCP 连接状态（建立 / 正常关闭 / 异常关闭 / 进行中），与 Wireshark 逐包一致；
3. 补全 TCP 其余字段（seq/ack_num/window），整包比对协议分布。

> 本周边界：状态推断是理解性训练；不做流级聚合与流数统计；TCP/UDP 传输层校验和不验证，读走即可（IPv4 头部校验和检查已在第 11 周任务④完成）。

## 二、前置检查（上周回顾）

- [ ] tcp 骨架已补全、`test_tcp` 全绿（第 11 周任务产出）
- [ ] `engine.exe pcap/malformed.pcap` 不崩溃，演进表三项已填（第 11 周完成后应为 6 包 / 5 异常）
- [ ] `engine.exe pcap/sample.pcap` 输出 40 / 0
- [ ] 本周下发的 tcp.h、parser.h、flags.pcap、gen_flags.py 已同步到本仓库
- [ ] 上周有效 commit ≥3 条，`git log --oneline` 可见

> 未过项先找助教补齐，再进入本周任务。

## 三、输入材料

| 文件或章节 | 内容 | 必读/参考 |
|---|---|---|
| `src/proto/udp.{h,cpp}` | UDP 解析骨架（函数体 TODO） | 必读 |
| `src/proto/tcp.h` | 下发更新版：`infer_tcp_state` 签名、状态枚举与规则注释 | 必读 |
| `src/proto/tcp.cpp` | 第 11 周自己写的 tcp 解析——udp 写法照它搬；本周继续往里加字段与状态推断 | 必读 |
| `src/proto/parser.h` | 下发更新版：Packet 新增 seq / ack_num / window 字段 | 必读 |
| `src/util/byte_reader.h` | u16be / u32be / u8 / skip 接口 | 复用 |
| `pcap/sample.pcap` | ≥3 条完整 TCP 会话 + ≥2 条 UDP 会话 | 必读 |
| `pcap/flags.pcap` | 教师下发的标志位样例集（4 帧：SYN / RST / URG / PSH+URG） | 必读 |
| `pcap/malformed.pcap` | 含 TCP 头长度越界样例（第 11 周已字段级验证） | 参考 |

## 四、任务清单

### 任务明细

**① 补全 udp 骨架**

实现 `parse_udp`，写法照第 10、11 周自己写的解析器搬。

步骤：

1. `util::ByteReader` 按序读 src_port / dst_port / length / checksum；
2. 填 `pkt.has_udp = true`、`pkt.src_port`、`pkt.dst_port`；checksum 读走即可——Packet 没有对应字段，读了不存；
3. 全部读取套 try-catch，越界时 `pkt.parse_errors++`、累加全局计数后返回 false；
4. 在 `src/proto/ipv4.cpp` 的 switch 里取消 `case 17` 那行的注释，让 `parse_udp` 接入主链路（对照上周 `case 6` 的做法）；
5. 自验：重新编译，`engine.exe pcap\sample.pcap --jsonl out.jsonl`，抽查 UDP 包：端口合理（DNS 53、高位临时端口）、length ≤ 所属 IP 包的 total_len。

验收：udp.cpp 无 TODO；sample.pcap 仍输出 40 / 0；`--jsonl` 里 UDP 包端口与 length 合理。

依赖：第 11 周 tcp 写法。

**② TCP 连接状态推断：三次握手 / 四次挥手 / RST 关闭**

按 tcp.h 下发的签名补全 `infer_tcp_state`，验证三种连接起落方式。

步骤：

1. 读 tcp.h：`infer_tcp_state` 的输入是一条连接按时间序的标志位序列，输出为 TcpConnState 枚举；判定规则已写在注释中（出现 RST → 异常关闭；否则出现 FIN → 正常关闭；否则 SYN、SYN+ACK、纯 ACK 三者齐全 → 建立；其余 → 进行中）；
2. Wireshark 中用 `tcp.flags.syn==1` 过滤找 sample.pcap 的 3 条 TCP 会话（`tcp.stream eq N` 的 N 取 Statistics → Conversations → TCP 标签页行号），逐包抄下标志位列、手写推断结果并逐包核对，按附二格式写入 `docs/notes/week12_verify.md` 第一节；
3. 写 3 条单测：完整三次握手序列、FIN 正常关闭序列、RST 异常关闭序列，断言状态推断输出正确（骨架见附一）。

验收：`week12_verify.md` 第一节中 3 条会话各有"包号—标志位—推断状态"对照表且与 Wireshark 逐包一致；3 条状态单测全绿。

依赖：第 11 周 tcp 骨架。

**③ TCP 其余字段：seq / ack_num / window**

补全三个字段的解析，Packet 字段已由下发版 parser.h 提供。

步骤：

1. 按第 11 周 tcp 骨架的读取方式补三个字段填入 `Packet`；
2. 在 test_tcp 用例 1（SYN 包）中补断言：seq=1000、ack_num=0，与 kTcpSyn 数组中手工填入的值一致；
3. Wireshark 任取 2 个包核对 seq/ack 数值。

验收：test_tcp 全绿；Wireshark 抽 2 包 seq/ack 数值一致。

依赖：第 11 周 tcp 骨架。

**④ 整包比对：协议分布包数与字节**

与 Wireshark 整体验证。stats 模块第 15 周才实现，本周唯一可行路径是 JSONL 旁路。

步骤：

1. 跑 `engine.exe pcap\sample.pcap --jsonl out.jsonl`；
2. VS Code 打开 out.jsonl，Ctrl+F 分别搜 `"tcp":`、`"udp":`、`"icmp":`，右下角匹配计数即各协议包数，填入 `docs/notes/week12_verify.md` 第二节；
3. Wireshark：Statistics → Protocol Hierarchy，以 IPv4 行展开后的 TCP/UDP/ICMP 子行为准逐项核对包数；
4. 字节口径：`byte_cnt` = 各包 caplen 之和，抄下各协议 Bytes 列数值并核对；
5. UDP 会话数在 Statistics → Conversations → UDP 记录当前值备查。

验收：TCP/UDP/ICMP 包数与 Protocol Hierarchy 逐项一致（零误差）；字节数按 caplen 之和口径记录并核对。

依赖：任务①。


**⑤ flags.pcap 标志位核对**

核对教师下发的标志位样例集，确认引擎对 URG、PSH+URG、SYN→RST 三类少见标志位的解析与 Wireshark 逐位一致。本任务不涉及代码编写，跑引擎、对 Wireshark、填记录即可。

步骤：

1. 执行 `engine.exe pcap\flags.pcap`，预期处理包数 4、解析异常数 0；
2. 执行 `engine.exe pcap\flags.pcap --jsonl out_flags.jsonl`，核对 4 帧 tcp_flags 依次为 0x02（SYN）、0x04（RST）、0x20（URG）、0x28（PSH+URG）；PSH=0x08，PSH+URG 两位置 1 即 0x28；
3. Wireshark 打开 flags.pcap 逐帧核对 Flags 列，截图与核对结论按附二格式写入 `docs/notes/week12_verify.md` 第三节。

验收：4 帧标志位全部逐位一致；截图已存档。

依赖：任务①。

## 五、对照验证（本周 Wireshark 比对操作）

| 比对项 | Wireshark 位置 | 通过判据 |
|---|---|---|
| UDP 端口与 length | 包列表 Port 列 / UDP 详情树 | 随机抽 3 个 UDP 包逐字段一致 |
| TCP seq/ack/window | TCP 详情树 | 随机抽 2 包逐字段一致 |
| 连接建立序列 | 过滤 `tcp.stream eq N` 逐包看 Flags | SYN→SYN/ACK→ACK 顺序无颠倒 |
| 连接关闭方式 | 同上 | FIN 序列判"正常关闭"，RST 判"异常关闭"，与推断一致 |
| 协议分布包数 | Statistics → Protocol Hierarchy（IPv4 行展开的 TCP/UDP/ICMP 子行） | 包数与引擎 JSONL 计数逐项一致（零误差）；字节按 caplen 之和口径记录并核对 |
| UDP 会话数 | Statistics → Conversations → UDP | 记录当前值备查 |
| flags.pcap 标志位 | 包列表 Flags 列 | 4 帧与引擎 --jsonl 输出逐位一致 |

> 口径提醒：Conversations 窗口只显示地址/端口/包数，连接状态要看包列表 Flags 列逐包确认；Wireshark 没有"状态"列，状态由标志位序列推断。

## 六、输出物与提交要求

| 输出物 | 位置 |
|---|---|
| udp 模块实现 | `src/proto/udp.cpp` |
| TCP 其余字段 + 状态推断 | `src/proto/tcp.cpp` |
| 分发接入 | `src/proto/ipv4.cpp` |
| 状态对照 + 协议分布比对 + flags 核对（三节） | `docs/notes/week12_verify.md`（格式见附二） |
| 状态推断单测（3 条） | `tests/test_tcp.cpp` |
| 周报 | `docs/weekly/week12_report.md`（周二 12:00 前，一次 `docs:` 提交，计入本周 ≥3 次有效提交） |

提交要求：本周有效 commit ≥3 条（含周报一次），格式 `type: 说明`。commit 建议：`feat: 补全 udp 骨架解析`、`feat: 实现 tcp 连接状态推断`、`test: 状态推断单测`、`docs: 第12周周报`。

## 附一：test_tcp.cpp 新增用例骨架

在上周 test_tcp.cpp 基础上追加以下 3 条用例，直接构造标志位序列调用 `infer_tcp_state`，不需要造包头。

```cpp
// 用例 4：三次握手序列 → Established
TEST_CASE("tcp 状态推断: 三次握手", "[tcp][state]") {
    const uint8_t seq[] = {0x02, 0x12, 0x10};   // SYN → SYN+ACK → ACK
    REQUIRE(infer_tcp_state(seq, 3) == TcpConnState::Established);
}

// 用例 5：握手后 FIN 关闭 → ClosedFin
TEST_CASE("tcp 状态推断: FIN 正常关闭", "[tcp][state]") {
    // TODO: 构造 SYN → SYN+ACK → ACK → FIN → ACK 序列, 断言 ClosedFin
}

// 用例 6：SYN 被拒即回 RST → ClosedRst
TEST_CASE("tcp 状态推断: RST 异常关闭", "[tcp][state]") {
    // TODO: 构造 SYN → RST 序列, 断言 ClosedRst
}
```

## 附二：记录文档格式（week12_verify.md）

任务②④⑥的三份记录合并为一个文件 `docs/notes/week12_verify.md`，共三节。把下面这份模板原样复制，空格（`__`）照实填，表头保留。

```markdown
# 第 12 周核对记录

## 一、TCP 连接状态对照（任务②，3 条会话各一张表，标注 tcp.stream eq N）

### 会话 1（tcp.stream eq 0，192.168.1.10:xxxxx → 8.8.8.8:443）

| 包号 | 标志位 | 推断状态 |
|---|---|---|
| 1 | 0x02 SYN | 发起连接 |
| 2 | 0x12 SYN+ACK | 对方同意，连接建立中 |
| 3 | 0x10 ACK | Established |
| ... | ... | ... |

### 会话 2（...）
（同上格式）

### 会话 3（...）
（同上格式）

## 二、协议分布比对（任务④）

| 协议 | 引擎 JSONL 计数（Ctrl+F） | Wireshark Protocol Hierarchy 包数 | 字节（caplen 之和） | 是否一致 |
|---|---|---|---|---|
| TCP | | | | |
| UDP | | | | |
| ICMP | | | | |

UDP 会话数（Conversations → UDP）：__
结论：包数比对零误差 / 差异说明。

## 三、flags.pcap 标志位核对（任务⑥）

引擎运行：处理包数 __，解析异常数 __（预期 4 / 0）。

| 帧 | 引擎 tcp_flags | Wireshark Flags | 一致 |
|---|---|---|---|
| 1 SYN | | | |
| 2 RST | | | |
| 3 URG | | | |
| 4 PSH+URG | | | |

（此处粘贴 Wireshark 与 --jsonl 截图）
```
