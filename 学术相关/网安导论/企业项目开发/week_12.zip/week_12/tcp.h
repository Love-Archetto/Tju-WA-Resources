// ============================================================================
// 【骨架】tcp —— 传输层 TCP 解析（F4）
// ----------------------------------------------------------------------------
// 验收要点（规格书 5.4）: 标志位解析、连接状态推断
// （SYN→SYN/ACK→ACK 建立；FIN/RST 关闭）, 与 Wireshark Conversations 一致。
// 函数签名已定义; 函数体为 TODO 占位 —— 留空状态工程仍可编译可运行。
// ============================================================================
#pragma once

#include "proto/parser.h"

#include <cstdint>

// 【骨架】学生补全函数体
// 要求：使用 util::ByteReader 读取字段；任何越界/异常走 try-catch 并累加
//       pkt.parse_errors 与 util::add_parse_error()；注意头长(data offset)
//       可能越界（malformed.pcap 中有此类样例）。
// 返回: true = 识别为 TCP 并已填充 pkt 的 TCP 字段。
bool parse_tcp(pkt::Packet& pkt, const uint8_t* data, uint32_t len);

// 【骨架】连接状态枚举（第 12 周任务②）：按一条连接的标志位序列推断其状态
enum class TcpConnState : uint8_t {
    InProgress = 0,   // 进行中：未完成建立，也无 FIN/RST
    Established,      // 建立：SYN → SYN+ACK → ACK 三步齐全
    ClosedFin,        // 正常关闭：出现过 FIN
    ClosedRst         // 异常关闭：出现过 RST
};

// 【骨架】学生补全函数体（第 12 周任务②）
// 输入: flags_seq —— 一条连接按时间序的标志位序列（每个元素为一个报文的
//       tcp_flags，即低 6 个标志位）；n —— 序列长度（报文个数）。
// 规则: 出现 RST → ClosedRst；否则出现 FIN → ClosedFin；
//       否则 SYN、SYN+ACK、纯 ACK 三者都出现 → Established；其余 → InProgress。
TcpConnState infer_tcp_state(const uint8_t* flags_seq, uint32_t n);
