// ============================================================================
// 【提供】parser.h —— 解析器统一接口与 Packet 结构体定义
// ----------------------------------------------------------------------------
// 本文件是全部协议解析器的公共约定:
//   - Packet: 一包数据的"解析结果容器", 各层解析器逐级填充字段;
//   - IParser: 解析器统一接口, 是大二"解析器插件化"的雏形。
// 学生只需要读懂, 不需要修改本文件。
// ============================================================================
#pragma once

#include <cstdint>

namespace pkt {

// ---------------------------------------------------------------------------
// Packet: 一包数据的解析结果。
// 原始字节(data)由 pcap_reader 提供, 只读、零拷贝; 各层解析器填充下方字段。
// 未被识别/未解析的层保持默认值(false / 0)。
// ---------------------------------------------------------------------------
struct Packet {
    uint64_t ts_us = 0;        // 捕获时间戳（微秒）
    uint32_t caplen = 0;       // 捕获长度（实际抓到的字节数）
    const uint8_t* data = nullptr;  // 原始字节（只读，零拷贝）

    // 各层解析结果（解析器逐级填充；未解析层保持默认值）
    bool     has_eth   = false;
    uint8_t  eth_src[6] = {0}, eth_dst[6] = {0};
    uint16_t eth_type  = 0;

    bool     has_ipv4  = false;
    char     ipv4_src[16] = {0}, ipv4_dst[16] = {0};   // 点分十进制
    uint8_t  ipv4_proto = 0;
    uint8_t  ipv4_ttl  = 0;
    uint16_t ip_total_len = 0;
    bool     ip_frag   = false;            // 分片标志

    bool     has_tcp = false, has_udp = false, has_icmp = false;
    uint16_t src_port = 0, dst_port = 0;
    uint8_t  tcp_flags = 0;                // FIN/SYN/RST/PSH/ACK/URG 位
    uint32_t seq = 0, ack_num = 0;         // TCP 序号 / 确认号（第 12 周任务③）
    uint16_t window = 0;                   // TCP 窗口（第 12 周任务③）

    // ---- ARP / ICMP / 应用层字段（骨架扩展, 5.3 中"此处从略"的部分）----
    bool     has_arp  = false;
    uint16_t arp_op   = 0;                 // ARP 操作码: 1=request, 2=reply
    bool     has_icmp_fields = false;      // ICMP 类型/代码已解析
    uint8_t  icmp_type = 0, icmp_code = 0;

    uint32_t parse_errors = 0;             // 本包解析异常计数（健壮性考核）
};

// TCP 标志位掩码（tcp_flags 字段使用）
inline constexpr uint8_t TCP_FIN = 0x01;
inline constexpr uint8_t TCP_SYN = 0x02;
inline constexpr uint8_t TCP_RST = 0x04;
inline constexpr uint8_t TCP_PSH = 0x08;
inline constexpr uint8_t TCP_ACK = 0x10;
inline constexpr uint8_t TCP_URG = 0x20;

// ---------------------------------------------------------------------------
// IParser: 解析器统一接口
// 返回 true 表示本层识别成功并已填充字段；false 表示不匹配，交给下一解析器
// ---------------------------------------------------------------------------
class IParser {
public:
    virtual ~IParser() = default;
    virtual bool parse(Packet& pkt) = 0;
};

} // namespace pkt
