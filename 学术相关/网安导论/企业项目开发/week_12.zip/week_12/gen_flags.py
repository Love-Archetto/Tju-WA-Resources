#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_flags.py —— 生成 pcap/flags.pcap（TCP 标志位样例集, 教师提供）
================================================================================
共 4 帧，每帧只含一个标志位知识点，IP 校验和全部正确：

  1. SYN    10.0.0.1:5000 → 10.0.0.2:80   发起连接
  2. RST    10.0.0.2:80  → 10.0.0.1:5000  对第 1 帧的回应——连接被拒
  3. URG    10.0.0.1:5001 → 10.0.0.2:80   纯 URG（ urg 指针位置有效载荷）
  4. PSH+URG 10.0.0.1:5002 → 10.0.0.2:80  两个标志位同时置 1

预期行为(教师 reference-week12 实测口径): 处理包数 4、解析异常数 0,
--jsonl 中 tcp_flags 依次为 0x02 / 0x04 / 0x20 / 0x28, 与 Wireshark 逐位一致。

运行: python3 pcap/gen_flags.py
"""
import os
import struct

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "flags.pcap")
T0 = 1697000000

PCAP_GLOBAL_HDR = struct.pack("<IHHIIII", 0xA1B2C3D4, 2, 4, 0, 0, 65535, 1)  # little endian


def ip_checksum(hdr: bytes) -> int:
    """标准 IPv4 头校验和（生成时用, 保证各帧 IP 层完全合法）。"""
    if len(hdr) % 2:
        hdr += b"\x00"
    s = sum(struct.unpack("!%dH" % (len(hdr) // 2), hdr))
    while s >> 16:
        s = (s & 0xFFFF) + (s >> 16)
    return (~s) & 0xFFFF


def record(ts_sec, ts_usec, payload):
    """手工拼一条 pcap 记录。"""
    return struct.pack("<IIII", ts_sec, ts_usec, len(payload), len(payload)) + payload


def tcp_segment(sport, dport, flags):
    """20 字节 TCP 固定头, 仅标志位按参数填。"""
    return struct.pack("!HHIIBBHHH",
                       sport, dport,
                       0,          # seq
                       0,          # ack_num
                       0x50,       # 第 12 字节：data_offset=5 → 头长 20
                       flags,      # 第 13 字节：标志位（本文件唯一变量）
                       0x2000,     # window
                       0x0000,     # checksum（引擎读走不验）
                       0x0000)     # urgent_ptr


def frame(src_ip, dst_ip, tcp):
    """以太网 + IPv4(proto=6, 校验和正确) + TCP。"""
    ip_wo_sum = struct.pack("!BBHHHBBH4s4s",
                            0x45, 0x00, 20 + len(tcp), 0x0001, 0x0000,
                            64, 6, 0,
                            bytes(src_ip), bytes(dst_ip))
    ip = ip_wo_sum[:10] + struct.pack("!H", ip_checksum(ip_wo_sum)) + ip_wo_sum[12:]
    eth = bytes.fromhex("020000000002020000000001") + struct.pack("!H", 0x0800)
    return eth + ip + tcp


def main():
    frames = [
        tcp_segment(5000, 80, 0x02),   # 1. SYN
        tcp_segment(80, 5000, 0x04),   # 2. RST（回应 SYN，连接被拒）
        tcp_segment(5001, 80, 0x20),   # 3. 纯 URG
        tcp_segment(5002, 80, 0x28),   # 4. PSH+URG
    ]
    src = [10, 0, 0, 1]
    dst = [10, 0, 0, 2]

    with open(OUT, "wb") as fp:
        fp.write(PCAP_GLOBAL_HDR)
        for i, tcp in enumerate(frames):
            if i == 1:  # 第 2 帧方向反转：服务器 → 客户端
                payload = frame(dst, src, tcp)
            else:
                payload = frame(src, dst, tcp)
            fp.write(record(T0 + i, 0, payload))

    print("生成 %s: 4 帧(SYN/RST/URG/PSH+URG), %d 字节"
          % (OUT, os.path.getsize(OUT)))


if __name__ == "__main__":
    main()
