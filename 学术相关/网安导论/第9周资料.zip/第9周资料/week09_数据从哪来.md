# 第 9 周开发任务：pcap 文件格式与引擎数据流

**周次**：校历第 9 周（10 月 28 日）　**对应功能项**：F1（pcap 文件读取）
**截止时间**：下周二(11月3日) 12:00 前，与周报同时提交　**预计用时**：约 3 小时

## 一、任务目标

1. 掌握 pcap 文件格式：全局头 24 字节、包记录头 16 字节的字段布局，能和引擎代码里的读取语句一一对应；
2. 理解回调模式 `read_all(cb)`：每读出一个包调用一次回调，读取与处理分离；
3. 理解引擎数据流主线：pcap → 解析 → 流表 → 统计 → 写库。

## 二、开发准备

Git、编译环境、托管平台账号第 8 周已装好，不再重复。

- [ ] `insightflow-scaffold.zip` 已解压到仓库根目录，能看到 `src/`、`tests/`、`pcap/`、`CMakeLists.txt`
- [ ] 第 8 周任务已全部提交至个人仓库

## 三、项目目录结构

```text
仓库根目录
├── src/
│   ├── io/         pcap_reader、live_capture
│   ├── proto/      ethernet、ipv4、arp、icmp、tcp、udp、app_ident、parser.h
│   ├── flow/       flow_key.h、flow_table、stats
│   ├── export/     db_writer、jsonl_exporter
│   ├── util/       byte_reader、logger
│   └── main.cpp
├── tests/          test_ethernet.cpp、test_main.cpp
├── pcap/           sample.pcap、malformed.pcap、gen_sample.py、gen_malformed.py
├── tools/          run_security_scan.sh、run_security_scan.bat
├── docs/           contract_v1.0.sql、contract_v1.0.md、answers/
├── CMakeLists.txt
└── .gitignore
```

两条约定：源文件头注释带【提供】【样例】【骨架】【扩展点】四级标注；本周不写新代码，第 10 周起补全【骨架】TODO。

## 四、开发任务

两个任务：任务一把脚手架导入 Git，任务二写《项目结构说明》。

### 任务一：导入脚手架、验证运行、基线提交（约 100 分钟）

把脚手架解压进个人仓库，编译、运行、逐项验证，跑通后做基线提交。第 10 周起每补一个解析器都要重跑这套流程，本周先跑通一遍。

**步骤**：

1. 解压 `insightflow-scaffold.zip` 到仓库根目录；
2. 编译：`cmake -B build`，再 `cmake --build build --config Release`。首次构建自动下载 sqlite3 与 Catch2，保持联网。`engine.exe` 是编译产物，由 CMake 输出到仓库根目录；Linux/Mac 下文件名是 `engine`，没有 .exe 后缀；
3. 运行 `engine.exe pcap\sample.pcap`（PowerShell 写 `.\engine.exe pcap\sample.pcap`），逐项核对输出：

   ```text
   ========================================
   InsightFlow 引擎处理完成
     输入文件    : pcap/sample.pcap
     处理包数    : 40
     解析异常数  : 0
     数据库      : ./insightflow.db
   ========================================
   ```

4. 输出必须与预期逐项一致：处理包数 40、解析异常数 0、数据库文件生成。任何一项不符，先排查环境再往下做；
5. 独立核算：按第 8 周 `first_pcap.cpp` 的思路统计 `pcap/sample.pcap` 的包记录头个数，与"处理包数: 40"比对。两个独立实现结果相同，即完成一次交叉验证；
6. 基线提交：`git add .` → `git commit -m "chore: 导入引擎脚手架"` → `git push`，网页端确认 commit 可见。

**截图清单（共 2 张，任务一截好，贴进《项目结构说明》第 3 节）**：

| # | 截什么 | 合格标准 |
| --- | --- | --- |
| 1 | cmake 配置 + 构建成功 | 命令和"构建成功"输出都入镜 |
| 2 | engine 运行输出 | 含"处理包数: 40、解析异常数: 0"整段输出框 |

图片入库：.png 放 `docs/design/`，Markdown 用相对路径引用，和 .md 一起 add、commit、push。本机绝对路径和图床外链在 Gitee 网页端会裂图。

### 任务二：阅读工程结构，写《项目结构说明》（约 60 分钟）

通读工程目录，写 `docs/design/project_structure.md`，按下面大纲：

```markdown
# 项目结构说明
## 1. 一句话概述
   工程整体是干什么的：输入是什么、输出是什么。
## 2. 目录逐个说明
   每个目录一个小节，写三句：里面有什么、作用是什么、本周改不改。
   覆盖 src/ 五个子目录、tests/、pcap/、docs/、tools/、CMakeLists.txt、.gitignore
## 3. 编译、运行与核对
   贴任务一的 2 张截图；写核算结论：你数的包数与引擎的 40 是否一致。
## 4. 没看懂的地方（可选）
   哪个文件或目录看不懂、想问什么，例会答疑用。
```

要求：第 2 部分覆盖全部目录；每个目录三句话以内，用自己的话；第 3 部分截图与核算结论齐全。这份文档期末原样并入《设计文档》。

提交：`git add docs/design/project_structure.md` → `git commit -m "docs: 第9周项目结构说明"` → `git push`。

## 五、提交要求

| 提交物 | 位置 | 说明 |
| --- | --- | --- |
| 基线提交 | 远程仓库 | 任务一，单独一次，计入 3 条 |
| 《项目结构说明》 | 仓库 `docs/design/project_structure.md` | 任务二 |
| 周报 | 仓库 `docs/weekly/week09_report.md` | 周二 12:00 前，单独一次 `docs:` 提交 |

本周有效 commit 不少于 3 条，含周报一次。commit 建议：`chore: 导入引擎脚手架`、`docs: 第9周项目结构说明`、`docs: 第9周周报`。
